#include <stdio.h>
#include <time.h>
#include "date.h"

int main() {

    // Initialize two dates using the structure date
    date birthday, today;

    // Ask the user to enter its birthdate using the function
    // parse_formatted_date in date.h file.
    // Store the string in the variables bi_string
    // Uses the function parse_formatted_date to get the values
    // of the day, month and year
    printf("Enter your birthday (DD/MM/YYYY) :");
    char bi_string[10];
    scanf("%s", bi_string);
    parse_formatted_date(bi_string, &birthday);

    // Check if the date birthay is valid using the function
    // is_date_valied defined in date.h
    // If so, the program continue
    // If not, the program stops
    if (is_date_valid(birthday)) {
        printf("The date entered is valid\n");
    }
    else {
        printf("The date entered is not valid\n");
        return 0;
    }

    // Repeat the same process for today's date
    printf("Enter your today's date (DD/MM/YYYY) :");
    char to_string[10];
    scanf("%s", to_string);
    parse_formatted_date(to_string, &today);

    // Check if both dates are valid (The first one must be
    // because of the last conditon) using is_date_valid
    // If so, the program continues
    // If not, the program stops
    if (is_date_valid(birthday) && is_date_valid(today)) {
        printf("Both of the dates entered are valid\n");
    }
    else {
        printf("The dates entered are not valid\n");
        return 0;
    }
    // Uses the function calculate_age to calculate
    // the age of the user
    int age = calculate_age(birthday, today);

    printf("The person's age is: %d\n", age);

    // Not enough time
    time_t now = time(0);
    //struct tm * today = ...

    return 0;
}

// To compile gcc -o output main.c -lm


