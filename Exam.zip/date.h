#ifndef DATE_H_
#define DATE_H_

// Defines the structure date.
// A date is composed of a day, a month and a year.
typedef struct {
    int day;
    int month;
    int year;
} date;

// Parses a string 'formatted_date' representing a date
// in format DD-MM-YYYY, DD.MM.YYYY or DD/MM/YYYY
// into a structure date 'parsed_date'.
void parse_formatted_date(char * formatted_date, date * parsed_date) {
    // Uses the sscanf to read a string from the user
    // Input the result in three integers of the structure date

    sscanf(formatted_date, "%d/%d/%d", &parsed_date->day, &parsed_date->month, &parsed_date->year);
}


void parse_system_date(struct tm system_date, date * parsed_date) {
    // The day of parsed_date is set to the
    // day of system_date which is defined using
    // the librairy time.h
    // Same process for month and year

    parsed_date->day = system_date.tm_mday;
    parsed_date->month = system_date.tm_mon;
    parsed_date->year = system_date.tm_year + 1900; // Time since 1900
}

int is_date_valid(date somedate) {

    int day = somedate.day;
    int month = somedate.month;
    int year = somedate.year;

    // Check if day is between 1 to 31
    if (day < 1 || day > 31) {
        printf("Error: The day is not valid\n");
        return 0;
    }

    // Check if month is between 1 to 12
    if (month < 1 || month > 12) {
        printf("Error: The month is not valid\n");
        return 0;
    }

    // Check if specified months are less than 30
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        if (day > 30) {
            printf("Error: The day is not valid\n");
            return 0;
        }
    }
    // Check if Feb is less than 28 (or 29 if leap year)
    else if (month == 2) {
        if (year % 400 == 0) {
            if (year % 100 != 0) {
                if (year % 4 == 0) {
                    if (day > 29) {
                        printf("Error: The day is not valid\n");
                        return 0;
                    }
                }
            }
        }
        else {
            if (day > 28) {
                printf("Error: The day is not valid\n");
                return 0;
            }
        }
    }

    // Returns 1 if all conditions are satisfied
    return 1;
}

int calculate_age(date birthday, date today) {

    // Set two integers variables equal to the year of the
    // person's birthday and today's year
    int year_bi = birthday.year;
    int year_to = today.year;

    // Assume that the person is at least one year old so
    // there is no need to use if statements
    int age = year_to - year_bi;

    // Returns the difference between the two ages
    return age;
}

#endif

